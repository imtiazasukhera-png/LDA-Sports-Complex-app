import { PrismaClient, MembershipType, PaymentStatus, BookingStatus } from '@prisma/client';
const prisma = new PrismaClient();
async function main() {
  const member = await prisma.member.upsert({where:{email:'umar@example.com'},update:{},create:{name:'Umar Farooq',email:'umar@example.com',phone:'0300-0000000',memberCode:'LDA000123'}});
  const names = [
    ['Gulberg Sports Complex','Gulberg, Lahore',49],['Johar Town Sports Complex','Johar Town, Lahore',38],['Sabzazar Sports Complex','Sabzazar, Lahore',35],['Canal West Sports Complex','Canal Bank Road, Lahore',46],['Minar-e-Pakistan Sports Complex','Minar-e-Pakistan, Lahore',null],['Islamia Ground Sports Complex','Lahore',null],['Tajpura Sports Complex','Tajpura, Lahore',null]
  ] as const;
  for (const [name,location,areaKanals] of names) {
    const c=await prisma.sportsComplex.upsert({where:{name},update:{},create:{name,location,areaKanals,imageUrl:'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800'}});
    for (const f of ['Gym','Swimming Pool','Badminton','Squash','Table Tennis','Snooker','Padel Courts','Classes']) await prisma.facility.create({data:{name:f,complexId:c.id}}).catch(()=>{});
    if(name==='Johar Town Sports Complex') for(const court of ['Court 1','Court 2','Court 3']) await prisma.court.create({data:{name:court,hourlyRate:3500,complexId:c.id}});
  }
  const membership=await prisma.membership.upsert({where:{memberId:member.id},update:{},create:{memberId:member.id,type:MembershipType.FAMILY,planName:'Monthly Family Membership',monthlyFee:7000,annualFee:100000,validUntil:new Date('2026-12-31')}});
  for(let i=0;i<4;i++){const d=new Date(2026,8-i,1); await prisma.monthlyFee.upsert({where:{memberId_month:{memberId:member.id,month:d}},update:{},create:{memberId:member.id,month:d,amount:7000,status:PaymentStatus.PAID,paidAt:new Date(d.getFullYear(),d.getMonth(),5)}})}
  console.log({memberId:member.id,membershipId:membership.id});
}
main().finally(()=>prisma.$disconnect());

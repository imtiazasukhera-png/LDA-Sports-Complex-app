import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { BookingStatus, PaymentStatus } from '@prisma/client';

@Controller()
export class AppController {
 constructor(private prisma:PrismaService){}
 @Get('health') health(){return {ok:true};}
 @Get('complexes') complexes(){return this.prisma.sportsComplex.findMany({include:{facilities:true,courts:true}});}
 @Get('complexes/:id') complex(@Param('id') id:string){return this.prisma.sportsComplex.findUnique({where:{id:+id},include:{facilities:true,courts:true}});}
 @Get('members/:id') async member(@Param('id') id:string){return this.prisma.member.findUnique({where:{id:+id},include:{membership:true,fees:{orderBy:{month:'desc'}},bookings:{include:{complex:true,court:true,payment:true},orderBy:{startAt:'asc'}}}});}
 @Get('members/:id/fees') fees(@Param('id') id:string){return this.prisma.monthlyFee.findMany({where:{memberId:+id},orderBy:{month:'desc'}});}
 @Post('fees/:feeId/pay') async payFee(@Param('feeId') feeId:string,@Body() body:{memberId:number;method:string}){
   const fee=await this.prisma.monthlyFee.update({where:{id:+feeId},data:{status:PaymentStatus.PAID,paidAt:new Date()}});
   const payment=await this.prisma.payment.create({data:{memberId:body.memberId,feeId:fee.id,amount:fee.amount,method:body.method,status:PaymentStatus.PAID,transactionId:`LDAFEE-${Date.now()}`}});
   return {fee,payment};
 }
 @Get('courts/:courtId/availability') async availability(@Param('courtId') courtId:string,@Query('date') date:string){
   const day=new Date(date); const next=new Date(day); next.setDate(day.getDate()+1);
   const bookings=await this.prisma.booking.findMany({where:{courtId:+courtId,startAt:{gte:day,lt:next},status:{not:BookingStatus.CANCELLED}},select:{startAt:true,endAt:true}});
   const slots=[]; for(let h=7;h<=21;h++){const start=new Date(day);start.setHours(h,0,0,0);const end=new Date(day);end.setHours(h+1,0,0,0);slots.push({startAt:start,endAt:end,available:!bookings.some(b=>b.startAt<end&&b.endAt>start)});} return slots;
 }
 @Post('bookings') async book(@Body() body:{memberId:number;complexId:number;courtId:number;startAt:string;endAt:string}){
   const court=await this.prisma.court.findUniqueOrThrow({where:{id:body.courtId}});
   const conflict=await this.prisma.booking.findFirst({where:{courtId:body.courtId,status:{not:BookingStatus.CANCELLED},startAt:{lt:new Date(body.endAt)},endAt:{gt:new Date(body.startAt)}}});
   if(conflict) return {error:'Time slot is no longer available'};
   return this.prisma.booking.create({data:{memberId:body.memberId,complexId:body.complexId,courtId:body.courtId,startAt:new Date(body.startAt),endAt:new Date(body.endAt),amount:court.hourlyRate,status:BookingStatus.CONFIRMED},include:{complex:true,court:true}});
 }
 @Get('members/:id/bookings') bookings(@Param('id') id:string){return this.prisma.booking.findMany({where:{memberId:+id},include:{complex:true,court:true,payment:true},orderBy:{startAt:'asc'}});}
 @Post('payments') async payment(@Body() body:{memberId:number;bookingId?:number;amount:number;method:string}){return this.prisma.payment.create({data:{memberId:body.memberId,bookingId:body.bookingId,amount:body.amount,method:body.method,status:PaymentStatus.PAID,transactionId:`LDAPAY-${Date.now()}`}});}
}

# Build the Android APK

This Flutter app is prepared for Android release. The demo build is self-contained and does not require the NestJS server to run.

## Easiest method: GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder, keeping `flutter_app` as the repository root (or upload only the contents of `flutter_app`).
3. Open **Actions → Build Android APK → Run workflow**.
4. When complete, open the workflow run and download the artifact **lda-sports-complexes-apk**.
5. Extract the artifact and install `app-release.apk` on Android.

The workflow uses Flutter stable and produces a release APK automatically.

## Local build
Install Flutter 3.35+ and Android Studio/SDK, then from `flutter_app`:

```bash
flutter pub get
flutter build apk --release
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Backend
The `backend` directory remains included for the production architecture:
Flutter → NestJS → PostgreSQL.
The APK demo currently uses local sample data so it opens and works immediately on a phone. For production, replace the local data layer with the API URLs and connect the payment gateway.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';

const green = Color(0xFF079447);
const dark = Color(0xFF10251D);
const bg = Color(0xFFF7F8F7);

final complexes = [
  {'id': 1, 'name': 'Gulberg Sports Complex', 'location': 'Gulberg, Lahore', 'size': '49 Kanals', 'facilities': ['Gym','Swimming Pool','Padel Courts','Badminton','Squash','Table Tennis'], 'image': 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=900'},
  {'id': 2, 'name': 'Johar Town Sports Complex', 'location': 'Johar Town, Lahore', 'size': '38 Kanals', 'facilities': ['Gym','Swimming Pool','Courts','Classes'], 'image': 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=900'},
  {'id': 3, 'name': 'Sabzazar Sports Complex', 'location': 'Sabzazar, Lahore', 'size': '35 Kanals', 'facilities': ['Gym','Swimming Pool','Badminton'], 'image': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=900'},
  {'id': 4, 'name': 'Canal West Sports Complex', 'location': 'Canal Bank Road, Lahore', 'size': '46 Kanals', 'facilities': ['Gym','Pool','Courts','Classes'], 'image': 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=900'},
  {'id': 5, 'name': 'Minar-e-Pakistan Sports Complex', 'location': 'Minar-e-Pakistan, Lahore', 'size': 'Sports Complex', 'facilities': ['Gym','Pool','Courts'], 'image': 'https://images.unsplash.com/photo-1519315901367-f34ff9154487?w=900'},
  {'id': 6, 'name': 'Islamia Ground Sports Complex', 'location': 'Lahore', 'size': 'Sports Complex', 'facilities': ['Gym','Courts','Classes'], 'image': 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=900'},
  {'id': 7, 'name': 'Tajpura Sports Complex', 'location': 'Tajpura, Lahore', 'size': 'Sports Complex', 'facilities': ['Gym','Pool','Courts'], 'image': 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=900'},
];

final member = {
  'name': 'Umar Farooq', 'memberCode': 'LDA000123', 'plan': 'Family Membership',
  'monthlyFee': 7000, 'validUntil': DateTime(2026, 12, 31),
};

final fees = [
  {'month': DateTime(2026, 9), 'amount': 7000, 'status': 'PAID'},
  {'month': DateTime(2026, 8), 'amount': 7000, 'status': 'PAID'},
  {'month': DateTime(2026, 7), 'amount': 7000, 'status': 'PAID'},
  {'month': DateTime(2026, 10), 'amount': 7000, 'status': 'DUE'},
];

final bookings = [
  {'complex': 'LDA Padel Arena', 'court': 'Court 1', 'date': DateTime(2026, 9, 28, 16), 'amount': 3500, 'status': 'Confirmed'},
  {'complex': 'Gulberg Sports Complex', 'court': 'Squash Court', 'date': DateTime(2026, 10, 1, 18), 'amount': 1500, 'status': 'Confirmed'},
];

void main() => runApp(const LdaApp());

class LdaApp extends StatelessWidget {
  const LdaApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'LDA Sports Complexes',
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: bg, colorScheme: ColorScheme.fromSeed(seedColor: green), fontFamily: 'Roboto'),
    home: const Shell(),
  );
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState() => _ShellState(); }
class _ShellState extends State<Shell> {
  int tab = 0;
  final pages = const [HomePage(), BookingPage(), MembershipPage(), ComplexesPage(), ProfilePage()];
  @override Widget build(BuildContext c) => Scaffold(
    body: pages[tab],
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Book'),
      NavigationDestination(icon: Icon(Icons.card_membership_outlined), label: 'Membership'),
      NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'Complexes'),
      NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
    ]),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext c) => SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
    Row(children: [const Icon(Icons.account_balance_outlined, size: 32), const SizedBox(width: 10), const Expanded(child: Text('LDA SPORTS COMPLEXES\nLAHORE', style: TextStyle(fontWeight: FontWeight.w800))), IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]),
    const SizedBox(height: 12),
    Container(height: 205, decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), image: const DecorationImage(fit: BoxFit.cover, image: NetworkImage('https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=1200'))), child: Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), gradient: const LinearGradient(colors: [Colors.black87, Colors.transparent], begin: Alignment.bottomLeft, end: Alignment.topRight)), child: const Align(alignment: Alignment.bottomLeft, child: Text('PLAY\nTRAIN\nSTAY HEALTHY', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800))))),
    const SizedBox(height: 16),
    TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Find a Sports Complex or Facility', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))),
    const SizedBox(height: 18),
    const Row(children: [Quick(icon: Icons.calendar_month, label: 'Book a Facility'), Quick(icon: Icons.person_add_alt, label: 'Membership'), Quick(icon: Icons.location_on_outlined, label: 'Our Complexes')]),
    const SizedBox(height: 22), const SectionTitle('Our Sports Complexes'),
    SizedBox(height: 170, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: complexes.length, separatorBuilder: (_, __) => const SizedBox(width: 12), itemBuilder: (_, i) => ComplexCard(data: complexes[i]))),
    const SizedBox(height: 20), const SectionTitle('Popular Facilities'),
    Wrap(spacing: 10, runSpacing: 10, children: ['Gym','Swimming Pool','Padel Courts','Squash','Badminton'].map((x) => Chip(avatar: const Icon(Icons.sports, size: 18), label: Text(x))).toList()),
    const SizedBox(height: 20),
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: dark, borderRadius: BorderRadius.circular(22)), child: const Row(children: [Expanded(child: Text('Become a Member\nAccess facilities across LDA Sports Complexes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 17))), Icon(Icons.arrow_forward_ios, color: Colors.white)])),
  ]));
}

class Quick extends StatelessWidget { final IconData icon; final String label; const Quick({required this.icon, required this.label, super.key}); @override Widget build(BuildContext c) => Expanded(child: Container(margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Column(children: [Icon(icon, color: green), const SizedBox(height: 5), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]))); }
class SectionTitle extends StatelessWidget { final String text; const SectionTitle(this.text, {super.key}); @override Widget build(BuildContext c) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))); }
class ComplexCard extends StatelessWidget { final dynamic data; const ComplexCard({required this.data, super.key}); @override Widget build(BuildContext c) => SizedBox(width: 235, child: Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Image.network(data['image'], fit: BoxFit.cover, width: double.infinity, errorBuilder: (_, __, ___) => const Icon(Icons.image, size: 50))), Padding(padding: const EdgeInsets.all(10), child: Text(data['name'], maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800)))]))); }

class ComplexesPage extends StatelessWidget { const ComplexesPage({super.key}); @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Sports Complexes', style: TextStyle(fontWeight: FontWeight.w800))), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: complexes.length, itemBuilder: (_, i) { final x = complexes[i]; return Card(child: ListTile(leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(x['image'], width: 70, height: 70, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.image))), title: Text(x['name'], style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${x['location']}\n${x['facilities'].length} facilities'), isThreeLine: true, trailing: const Icon(Icons.chevron_right))); })); }

class BookingPage extends StatefulWidget { const BookingPage({super.key}); @override State<BookingPage> createState() => _BookingPageState(); }
class _BookingPageState extends State<BookingPage> {
  int complexIndex = 0; int court = 1; DateTime date = DateTime.now(); String? slot;
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Book Padel Court', style: TextStyle(fontWeight: FontWeight.w800))), body: ListView(padding: const EdgeInsets.all(18), children: [
    DropdownButtonFormField<int>(initialValue: complexIndex, decoration: const InputDecoration(labelText: 'Select Sports Complex', filled: true), items: List.generate(complexes.length, (i) => DropdownMenuItem(value: i, child: Text(complexes[i]['name']))), onChanged: (v) => setState(() => complexIndex = v ?? 0)),
    const SizedBox(height: 14), const Text('Padel Court', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8),
    Wrap(spacing: 8, children: [1,2,3].map((x) => ChoiceChip(label: Text('Court $x'), selected: court == x, onSelected: (_) => setState(() => court = x))).toList()),
    const SizedBox(height: 18), CalendarDatePicker(initialDate: date, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 90)), onDateChanged: (d) => setState(() => date = d)),
    const SizedBox(height: 12), const Text('Available Time', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8),
    Wrap(spacing: 8, runSpacing: 8, children: List.generate(12, (i) { final h = 8 + i; final s = '${h.toString().padLeft(2,'0')}:00'; return ChoiceChip(label: Text(s), selected: slot == s, onSelected: (_) => setState(() => slot = s)); })),
    const SizedBox(height: 22), FilledButton(onPressed: slot == null ? null : () => showDialog(context: c, builder: (_) => AlertDialog(title: const Text('Booking Confirmed'), content: Text('Court $court\n${DateFormat('dd MMM yyyy').format(date)} at $slot\n\nCourt Fee: PKR 3,500'), actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('Done'))])), child: const Padding(padding: EdgeInsets.all(14), child: Text('Confirm Booking'))),
  ]));
}

class MembershipPage extends StatelessWidget { const MembershipPage({super.key}); @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Member Portal', style: TextStyle(fontWeight: FontWeight.w800))), body: ListView(padding: const EdgeInsets.all(18), children: [
  MemberHeader(), const SizedBox(height: 14), Card(child: ListTile(title: Text(member['plan'] as String, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('PKR ${member['monthlyFee']} / month\nValid until ${DateFormat('dd MMM yyyy').format(member['validUntil'] as DateTime)}'), trailing: const Chip(label: Text('Active')))),
  const SizedBox(height: 12), Card(child: ListTile(leading: const Icon(Icons.receipt_long, color: green), title: const Text('Monthly Fees & Payments'), subtitle: const Text('View and pay monthly membership fees'), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const FeesPage())))),
  Card(child: ListTile(leading: const Icon(Icons.calendar_month, color: green), title: const Text('My Bookings'), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const BookingsPage())))),
  Card(child: ListTile(leading: const Icon(Icons.qr_code_2, color: green), title: const Text('My Member QR'), onTap: () => showDialog(context: c, builder: (_) => AlertDialog(title: const Text('Member QR'), content: SizedBox(width: 220, height: 220, child: QrImageView(data: member['memberCode'] as String)), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close'))])))),
 ])); }

class MemberHeader extends StatelessWidget { const MemberHeader({super.key}); @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: dark, borderRadius: BorderRadius.circular(22)), child: Row(children: [const CircleAvatar(radius: 28, child: Icon(Icons.person)), const SizedBox(width: 12), Expanded(child: Text('${member['name']}\nMember ID: ${member['memberCode']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))), QrImageView(data: member['memberCode'] as String, size: 55, backgroundColor: Colors.white)])); }

class FeesPage extends StatefulWidget { const FeesPage({super.key}); @override State<FeesPage> createState() => _FeesPageState(); }
class _FeesPageState extends State<FeesPage> { @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Monthly Fees & Payments')), body: ListView(padding: const EdgeInsets.all(16), children: [const Card(child: ListTile(title: Text('Family Membership'), subtitle: Text('Monthly fee'), trailing: Text('PKR 7,000', style: TextStyle(fontWeight: FontWeight.w800)))), const SizedBox(height: 10), ...fees.map((x) => Card(child: ListTile(leading: Icon(x['status'] == 'PAID' ? Icons.check_circle : Icons.payment, color: x['status'] == 'PAID' ? green : Colors.orange), title: Text(DateFormat('MMMM yyyy').format(x['month'] as DateTime)), subtitle: Text('PKR ${x['amount']}'), trailing: x['status'] == 'PAID' ? const Text('Paid') : FilledButton(onPressed: () => _pay(c, x), child: const Text('Pay'))))) ])); }
 void _pay(BuildContext c, dynamic fee) { showDialog(context: c, builder: (_) => AlertDialog(title: const Text('Pay Monthly Fee'), content: const Text('Choose payment method'), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('JazzCash')), TextButton(onPressed: () => Navigator.pop(c), child: const Text('EasyPaisa')), FilledButton(onPressed: () { setState(() => fee['status'] = 'PAID'); Navigator.pop(c); ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Payment successful. Receipt generated.'))); }, child: const Text('Pay PKR 7,000'))])); }
}

class BookingsPage extends StatelessWidget { const BookingsPage({super.key}); @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('My Bookings')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: bookings.length, itemBuilder: (_, i) { final b = bookings[i]; return Card(child: ListTile(leading: const Icon(Icons.sports_tennis, color: green), title: Text('${b['complex']} • ${b['court']}'), subtitle: Text('${DateFormat('dd MMM, hh:mm a').format(b['date'] as DateTime)}\nPKR ${b['amount']}'), isThreeLine: true, trailing: Chip(label: Text(b['status'])))); })); }

class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Profile')), body: ListView(padding: const EdgeInsets.all(18), children: [MemberHeader(), const SizedBox(height: 15), ...['Membership Details','Monthly Fees & Payments','Payment History','My QR Code','Notifications','Help & Support','Settings'].map((x) => Card(child: ListTile(title: Text(x), trailing: const Icon(Icons.chevron_right), onTap: () { if (x == 'Monthly Fees & Payments') Navigator.push(c, MaterialPageRoute(builder: (_) => const FeesPage())); }))) ]); }
